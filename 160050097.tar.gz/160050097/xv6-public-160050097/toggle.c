#include "types.h"
#include "stat.h"
#include "user.h"

int main()
{
	int ret;
	int i;


	init_counters();

	acquire_lock(0);

	ret = fork();

	for(i=0;i<30;i++)
	{
		if(ret)
		{
			if(acquire_lock(1) == 1)
			{
				set_var(0, get_var(0)+1);
				printf(1,"In parent, %d\n", get_var(0));
				release_lock(0);
			}
		}
		else
		{
			if(acquire_lock(0) == 1)
			{
				set_var(0, get_var(0)-1);
				printf(1,"In child, %d\n", get_var(0));
				release_lock(1);
			}	
		}
	}

	if(ret == 0)
	{
		exit();
	}
	else
	{
		wait();
		exit();
	}
}
